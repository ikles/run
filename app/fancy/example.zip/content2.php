
<h2>Вы открыли окно № <?php echo $_GET["id"] ?></h2>