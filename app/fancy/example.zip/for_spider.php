<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="imagetoolbar" content="no" />
	<title>FancyBox</title>
    	<style>
		html, body {
			font: normal 12px Tahoma;
			color: #333;
		}
		
		a {
			outline: none;	
		}
		
		div#wrap {
			width: 500px;
			margin: 50px auto;	
		}

		img {
			border: 1px solid #CCC;
			padding: 2px;	
			margin: 10px 5px 10px 0;
			
			
		}
		
		.green 
		{color:#060; font-size:14px}
	
	</style>
</head>
<body>
<div id="wrap">
<h2>Эта страница для пауков и тех, кто придет к нам по их "наводке." </h2>
<p>Здесь мы выводим контент для модальных окон на самом сайте. Вот такая страховка.
</p>

<h2>Вы открыли окно № <?php echo $_GET["id"] ?></h2>

</div>





</body>
</html>